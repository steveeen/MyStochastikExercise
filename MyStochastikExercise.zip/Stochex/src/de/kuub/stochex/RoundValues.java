/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.kuub.stochex;

/**
 *
 * @author Bonke
 */
public enum RoundValues
{
    NoGermanTeam,
    OneGermanTeam,
    TwoGermanTeams
}